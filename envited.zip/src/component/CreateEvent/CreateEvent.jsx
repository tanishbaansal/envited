import React from "react";

const CreateEvent = () => {
    return <div>Create-Event</div>;
};

export default CreateEvent;
