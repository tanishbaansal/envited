import React from "react";
import "./Button.css";
const Button = (props) => {
    return <Button className="button">{props.text}</Button>;
};

export default Button;
