import "./App.css";
import Button from "./component/Button/Button";
import landingImage from "./assets/img/Landing page image.svg";
function App() {
    return (
        <div className="container">
            <div className="container-text">
                Imagine If <div className="container-text-special">Snapchat</div> had events.
            </div>
            <div className="container-subtext">
                Easily host and share events with your friends across any social media
            </div>
            <div className="container-image">
                <img src={landingImage} alt="landing page" />
            </div>
            <Button text="🎉 Create my event" to="/create-event" />
        </div>
    );
}

export default App;
